﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GQService.com.gq.dto
{
    public class XYLineasDto
    {
        public string Linea { get; set; }
        public string Tipo { get; set; }
        public string NI { get; set; }
        public string NF { get; set; }
        public string Long1 { get; set; }
        public string Lat1 { get; set; }
        public string Long2 { get; set; }
        public string Lat2 { get; set; }
    }
}
