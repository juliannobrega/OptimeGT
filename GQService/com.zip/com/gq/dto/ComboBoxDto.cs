﻿namespace GQService.com.gq.dto
{
    public class ComboBoxDto
    {
        public object Id { get; set; }
        public object Label { get; set; }
    }
}
