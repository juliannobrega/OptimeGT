﻿using System;

namespace GQService.com.gq.dto
{
    public interface IEntity
    {
    }
}
