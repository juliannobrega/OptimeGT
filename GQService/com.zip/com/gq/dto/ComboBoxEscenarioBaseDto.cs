﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GQService.com.gq.dto
{
    public class ComboBoxEscenarioBaseDto
    {
        public object Id { get; set; }
        public object Label { get; set; }
        public object FechaIni { get; set; }
        public object SemanaIni { get; set; }
        public object FechaFin { get; set; }
        public object SemanaFin { get; set; }
    }
}
