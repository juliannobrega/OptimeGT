﻿using GQService.com.gq.paging;

namespace GQService.com.gq.controller
{
    public interface IBuscar
    {
        Paging Buscar(Paging paging);
    }
}
